#!/sbin/sh
umount -l /dev/block/mmcblk0p12
/sbin/setprop ctl.stop console
kill -9 $(ps | grep /system/bin/chargemon)
kill -9 $(ps | grep /system/bin/tad)
kill -9 $(ps | grep /system/bin/time_daemon)